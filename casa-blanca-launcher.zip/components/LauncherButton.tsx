
import React from 'react';
import { SystemButton } from '../types';

interface LauncherButtonProps {
  system: SystemButton;
}

const LauncherButton: React.FC<LauncherButtonProps> = ({ system }) => {
  const handleClick = () => {
    window.location.href = system.url;
  };

  return (
    <button
      onClick={handleClick}
      className={`
        group relative flex items-center p-8 bg-[#161616] border border-white/5 
        rounded-3xl transition-all duration-300 active:scale-95 active:bg-[#1f1f1f]
        hover:border-white/20 hover:shadow-[0_0_30px_rgba(255,255,255,0.05)]
        text-left overflow-hidden
        ${system.fullWidth ? 'md:col-span-2' : ''}
      `}
    >
      {/* Visual background flourish */}
      <div className="absolute top-0 right-0 -mr-4 -mt-4 w-32 h-32 bg-white/5 blur-3xl rounded-full group-hover:bg-white/10 transition-colors" />
      
      <div className="mr-8 shrink-0">
        <div className="p-4 bg-white/5 rounded-2xl group-hover:bg-white/10 transition-colors">
          {system.icon}
        </div>
      </div>
      
      <div className="flex flex-col">
        <span className="text-2xl font-bold text-white mb-1 group-hover:text-white transition-colors">
          {system.name}
        </span>
        <span className="text-gray-400 font-medium tracking-wide">
          {system.description}
        </span>
      </div>
      
      {/* Accessibility indicator */}
      <div className="absolute right-8 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
        <svg 
          className="w-6 h-6 text-gray-400" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
      </div>
    </button>
  );
};

export default LauncherButton;
